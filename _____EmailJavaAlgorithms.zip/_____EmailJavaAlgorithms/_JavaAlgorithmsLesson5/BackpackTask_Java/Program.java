//
// Translated by CS2J (http://www.cs2j.com): 9/16/2018 12:16:10 AM
//

package BackpackTask;

import BackpackTask.Form1;
import BackpackTask.Program;

public class Program   
{
    /**
    * Главная точка входа для приложения.
    */
    public static void main(String[] args) throws Exception {
        Program.Main();
    }

    static void Main() throws Exception {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new Form1());
    }

}


