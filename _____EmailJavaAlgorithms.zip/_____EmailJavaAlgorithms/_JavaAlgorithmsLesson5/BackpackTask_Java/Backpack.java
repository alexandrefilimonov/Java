//
// Translated by CS2J (http://www.cs2j.com): 9/16/2018 12:16:09 AM
//

package BackpackTask;

import BackpackTask.Item;
import CS2JNet.System.Collections.LCC.CSList;

public class Backpack   
{
    private CSList<Item> bestItems = null;
    private double maxW;
    private double bestPrice;
    public Backpack(double _maxW) throws Exception {
        maxW = _maxW;
    }

    //создание всех наборов перестановок значений
    public void makeAllSets(CSList<Item> items) throws Exception {
        if (items.size() > 0)
            checkSet(items);
         
        for (int i = 0;i < items.size();i++)
        {
            CSList<Item> newSet = new CSList<Item>(items);
            newSet.remove((int));
            makeAllSets(newSet);
        }
    }

    //проверка, является ли данный набор лучшим решением задачи
    private void checkSet(CSList<Item> items) throws Exception {
        if (bestItems == null)
        {
            if (calcWeigth(items) <= maxW)
            {
                bestItems = items;
                bestPrice = calcPrice(items);
            }
             
        }
        else
        {
            if (calcWeigth(items) <= maxW && calcPrice(items) > bestPrice)
            {
                bestItems = items;
                bestPrice = calcPrice(items);
            }
             
        } 
    }

    //вычисляет общий вес набора предметов
    private double calcWeigth(CSList<Item> items) throws Exception {
        double sumW = 0;
        for (Item i : items)
        {
            sumW += i.getweigth();
        }
        return sumW;
    }

    //вычисляет общую стоимость набора предметов
    private double calcPrice(CSList<Item> items) throws Exception {
        double sumPrice = 0;
        for (Item i : items)
        {
            sumPrice += i.getprice();
        }
        return sumPrice;
    }

    //возвращает решение задачи (набор предметов)
    public CSList<Item> getBestSet() throws Exception {
        return bestItems;
    }

}


