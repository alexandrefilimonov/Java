package ru.geekbrains.Lesson2;
import ru.geekbrains.Lesson2.Item;
import java.util.ArrayList;
public class Backpack
{
    private ArrayList<Item> bestItems = null;
    private double maxW;
    private double bestPrice;
    public Backpack(double _maxW)  {
        maxW = _maxW;
    }

    //создание всех наборов перестановок значений
    public void makeAllSets(ArrayList<Item> items)  {
        if (items.size() > 0)
            checkSet(items);

        for (int i = 0;i < items.size();i++)
        {
            ArrayList<Item> newSet = new ArrayList<Item>(items);
            newSet.remove(i);
            makeAllSets(newSet);
        }
    }

    //проверка, является ли данный набор лучшим решением задачи
    private void checkSet(ArrayList<Item> items)  {
        if (bestItems == null)
        {
            if (calcWeigth(items) <= maxW)
            {
                bestItems = items;
                bestPrice = calcPrice(items);
            }

        }
        else
        {
            if (calcWeigth(items) <= maxW && calcPrice(items) > bestPrice)
            {
                bestItems = items;
                bestPrice = calcPrice(items);
            }

        }
    }

    //вычисляет общий вес набора предметов
    private double calcWeigth(ArrayList<Item> items)  {
        double sumW = 0;
        for (Item i : items)
        {
            sumW += i.getweigth();
        }
        return sumW;
    }

    //вычисляет общую стоимость набора предметов
    private double calcPrice(ArrayList<Item> items)  {
        double sumPrice = 0;
        for (Item i : items)
        {
            sumPrice += i.getprice();
        }
        return sumPrice;
    }

    //возвращает решение задачи (набор предметов)
    public ArrayList<Item> getBestSet()  {
        return bestItems;
    }

}



