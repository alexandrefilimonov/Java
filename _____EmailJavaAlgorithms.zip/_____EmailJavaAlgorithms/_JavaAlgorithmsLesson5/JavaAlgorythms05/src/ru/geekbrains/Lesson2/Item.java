package ru.geekbrains.Lesson2;

public class Item
{
    private String __name;
    public String getname() {
        return __name;
    }

    public void setname(String value) {
        __name = value;
    }

    private double __weigth;
    public double getweigth() {
        return __weigth;
    }

    public void setweigth(double value) {
        __weigth = value;
    }

    private double __price;
    public double getprice() {
        return __price;
    }

    public void setprice(double value) {
        __price = value;
    }

    public Item(String _name, double _weigth, double _price)  {
        setname(_name);
        setweigth(_weigth);
        setprice(_price);
    }

}



