package ru.geekbrains.algjava.lesson4.home;

public class MainClass {
}
