package ru.geekbrains.algjava.lesson4.home;

import java.util.Iterator;

public class List<T> implements Iterable<T> {
    @Override
    public Iterator<T> iterator() {
        return null;
    }
}
