package ru.geekbrains.Lesson2;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.*;
import java.lang.String;
import java.lang.Object;

public class Main {
    public static void main( String [] args ) {
        int size = 10;
        MyArr2 arr = new MyArr2( size );
        arr.insert( 5 );
        arr.insert( 1 );
        arr.insert( 2 );
        arr.insert( 5 );
        arr.insert( 4 );
        arr.insert( 5 );
        arr.insert( 6 );
        arr.insert( 5 );
        arr.insert( 8 );
        arr.insert( 9 );
        System.out.println( "Выводим массив" );
        arr.display();
        //arr.delete(1);
        //System.out.println( "Удаление из массива элемента '1'" );
        System.out.println( "В массиве есть значение 3 -" +arr.binaryFind(3));
        System.out.println( "В массиве есть значение 5 -" +arr.binaryFind(5));

        //arr = new MyArr2( 1000000 );
        MyArr2 arr2=new MyArr2( size );
        int [] temp = arr.copy();
        arr2.insert(temp, size);
        System.out.println( "\n" );

        System.out.println( "Создаем массив размерностью в 1000 000 элементов" );
        size=100000;
        arr=new MyArr2( size );
        System.out.println( "Заполняем массив в 100 000 элементов случайными целыми числами" );
        int i=0;
        for ( i = 0 ; i < size ; i++){
            Random r = new Random();
            arr.insert( r.nextInt(size) );
        }
        System.out.println( "Начинаем копировать массив, чтобы все методы сортировки были применены к одному и тому же массиву элементов" );
        arr2=new MyArr2( size );
        temp = arr.copy();
        arr2.insert(temp, size);
        System.out.println( "Копирование 1 заверщено." );

        System.out.println( "\n" );
        long a = System.currentTimeMillis();
        arr.sort01Bubble();
        System.out.println( "Время выполнения сортировки методом Пузырька в миллисекундах:"+ (System.currentTimeMillis()-a));
        // 2509742msec.
        System.out.println( "\n" );

        arr=arr2;
        System.out.println( "Начинаем копировать массив, чтобы все методы сортировки были применены к одному и тому же массиву элементов" );
        arr2=new MyArr2( size );
        temp = arr.copy();
        arr2.insert(temp, size);
        System.out.println( "Копирование 2 заверщено." );
        System.out.println( "\n" );
        a = System.currentTimeMillis();
        arr.sort02Select();
        System.out.println( "Время выполнения сортировки методом Выбора на том же массиве в миллисекундах:"+ (System.currentTimeMillis()-a));
        //706947мсек.

        arr=arr2;
        a = System.currentTimeMillis();
        arr.sort03Insert();
        System.out.println( "Время выполнения сортировки методом Вставки на том же массиве в миллисекундах:"+ (System.currentTimeMillis()-a));
        //322211мсек.
        System.out.println( "Общий итог: метод Встравки быстрее метода Выбора, который в свою очередь быстрее метода Пузырька.");
    }
}
/*public class Main {
    public static void main ( String [] args ) {
        int [] myArr ; //Определение ссылки на массив
        myArr = new int [ 10 ]; //Создание массива и сохранение ссылки на него
        int len = myArr.length;
        int [] myArr1 = { 1 , 2 , 3 , 4 , 5 , 2 };
        System.out.println( myArr1 [ 1 ]);
        int search = 3;

        for ( int j = 0 ; j < len ; j++){
            System.out.println ( myArr1[ j ]);
        }
        for ( i = 0 ; i < len ; i++){
            if ( myArr1[ i ] == search ) break;
        }
        for ( int j = i ; j < len - 1 ; j++){
            myArr1[ j ] = myArr1[ j + 1 ];
        }
        len--;
        for ( int j = 0 ; j < len ; j++){
            System.out.println( myArr1[ j ]);
        }
    }
}*/
/*
public class Main {
    public static void main ( String [] args ) {
        MyArr arr = new MyArr ( 10 );
        arr.setElement ( 0 , 5 );
        arr.setElement ( 1 , 5 );
        arr.setElement ( 2 , 5 );
        arr.setElement ( 3 , 5 );
        arr.setElement ( 4 , 5 );
        arr.setElement ( 5 , 5 );
        arr.setElement ( 6 , 1 );
        arr.setElement ( 7 , 5 );
        arr.setElement ( 8 , 5 );
        arr.setElement ( 9 , 5 );
        System.out.println( "Выводим массив" );
        for ( int j = 0 ; j < arr.getSize (); j++){
            System.out.println( arr.getElement( j ));
        }
        arr.deleteElement( 1 );
        System.out.println( "Выводим новый массив" );
        for ( int j = 0 ; j < arr.getSize(); j++){
            System.out.println( arr.getElement( j ));
        }
    }



public void insert( int value ){
        int i;
        for ( i = 0 ; i < this.size ; i++){
        if ( this.arr[ i ]> value)
            break;
        }
        for ( int j = this . size ; j > i ; j--){
            this.arr[ j ] = this.arr[ j - 1 ];
        }
        this.arr[ i ] = value;
        this.size ++;
}
public boolean find ( int value ){
        int i;
        for ( i = 0 ; i < this.size ; i ++){
            if ( this.arr[ i ] == value ) break;
        }
        if ( i == this.size)
            return false;
        else
            return true;
}
public void display(){
        for ( int i = 0 ; i < this.size ; i ++){
            System.out.println( this.arr[ i ]);
        }
}
public void delete( int value ){
        int i = 0;
        for ( i = 0 ; i < this.size ; i++){
            if ( this.arr[ i ] == value ) break;
        }
        for ( int j = i ; j < this.size - 1 ; j++){
            this.arr[ j ] = this.arr[ j + 1 ];
        }
        this.size--;
}
}
*/



