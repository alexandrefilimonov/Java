package ru.geekbrains.Lesson1;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.*;
import java.lang.String;
import java.lang.Object;
public class Main {

    public static void main(String[] args) {
        //System.out.println("\n20 Binary trees with random number between -100 and 100 in the note:");
        //power(2,6)=64
        int intQtyOfImbalancedTree=0;
        for(int i=0;i<20; i++) {
            Tree t = new Tree();
            for(int j=0;j<63; j++) {//7notes - depth 3; 63 notes - depth 6
                Random random = new Random();
                int randomNumber = random.nextInt(200) -100;
                t.insert(new TreeNoteNumber(randomNumber));
            }
            t.displayTreeToConsole();
            if(t.balancedTree==false) intQtyOfImbalancedTree+=1;;
        }
        System.out.println("Out of 20 trees with depth=6 (63 notes) with random numbers from -100 to 100 the imbalanced trees are "+intQtyOfImbalancedTree);
    }
}
