package ru.geekbrains.Lesson1;

public class TreeNoteNumber {
    private static int id = 0;
    int number;
    int uid;

    public TreeNoteNumber(int number) {
        this.number = number;
        this.uid = number; /*++id;*/
    }
}
