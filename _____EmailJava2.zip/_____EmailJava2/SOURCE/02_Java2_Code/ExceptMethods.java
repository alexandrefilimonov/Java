package exceptions;

public class ExceptMethods 
{
       public void one()
       {
            two();
       }
       public void two()
       {
            three();
       }
       public void three()
       {
            int a = 1;
            int b = 0;
            int с = a/b;
       }
}//ExceptMethods
