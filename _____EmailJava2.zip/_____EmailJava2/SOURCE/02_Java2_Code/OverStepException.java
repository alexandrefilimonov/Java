package exceptions;

public class OverStepException extends Exception implements MessageInterface {
    //implements MessageInterface - для общей информации

    private int number_1;
    private int number_2;

    public OverStepException(String message) {
        super(message);
    }

    //вариант конструктора с тремя параметрами 
    public OverStepException(String message, int number_1, int number_2) {
        super(message);
        this.number_1 = number_1;
        this.number_2 = number_2;
    }

    @Override
    public String getMessage() {
        return "Переопределённый метод getMessage()";
    }

    @Override
    public void printmessage() {
        System.out.println("Ошибка");
    }
}
