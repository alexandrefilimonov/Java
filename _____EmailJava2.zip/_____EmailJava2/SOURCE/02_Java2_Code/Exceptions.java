package exceptions;
public class Exceptions 
{
    private final static int i = 1;
    private final static int j = 1;

    public static int division()
    {
      return j/i;
    }
 
    public static void main(String[] args) throws OverStepException 
    {
       
/////////////////////////////////////////////////////////////////////////////
        /*  
        Collatz cl  = new Collatz();
        /*
        try
        {
            cl.get_collatz_sequence(3, 3);
        }
        catch(OverStepException e)
        {
           System.out.println(e.getMessage());
           e.printmessage();//ради знаний
        }
        
        
        cl.get_collatz_sequence(3, 3);
        */
/////////////////////////////////////////////////////////////////////////////
        
        int a = 1;
        int b = 0;
        int[] c = { 1, 2, 3, 4, 5 };
        
        try
        {
            try
            {
               c[10] = 7;
               int d = a / b;
            }
            catch(ArithmeticException e)
            {
              System.out.println(e.getMessage());
            }
        }
        catch(IndexOutOfBoundsException e)
        {
           System.out.println(e.toString());
        }
        
/////////////////////////////////////////////////////////////////////////////
        /*
        ExceptMethods em = new ExceptMethods();
        em.one();
        */
/////////////////////////////////////////////////////////////////////////////
        /*
        String[] smass = new String[]{"One", "Two", null, "Three"};

        for(String str: smass)
        {
            try
            {
                System.out.println("Длина слова составляет " + str.length() + " букв(ы)");
            }
            catch(Exception ex)
            {
               System.out.println(ex + " Тут есть проблема");
            }
        }
        */
    }//main
}//class Exceptions 


