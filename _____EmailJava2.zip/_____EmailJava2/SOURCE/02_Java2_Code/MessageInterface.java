
package exceptions;

public interface MessageInterface {

     public void printmessage();
    
}
