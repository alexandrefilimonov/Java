/*
 */
package urldemo;
import java.net.*; 

class URLDemo { 
  public static void main(String args[]) throws MalformedURLException { 
    URL yandex = new URL("http://www.yandex.ru"); 
 
    System.out.println("Protocol: " + yandex.getProtocol()); 
    System.out.println("Port: " + yandex.getPort()); 
    System.out.println("Host: " + yandex.getHost()); 
    System.out.println("File: " + yandex.getFile()); 
    System.out.println("Ext:" +   yandex.toExternalForm()); 
  } 
}
