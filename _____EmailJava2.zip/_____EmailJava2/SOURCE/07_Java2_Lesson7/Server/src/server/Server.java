package server;

import java.net.*;
import java.util.*;
import java.io.*;

public class Server {

    public static void main(String[] args) {

          try{
          
               ServerSocket serv_socket = new ServerSocket(12345);
               System.out.println("Waiting for a new Client!");
               
               Socket socket = serv_socket.accept();
               
               DataInputStream  in = new DataInputStream(socket.getInputStream());
               DataOutputStream out = new DataOutputStream(socket.getOutputStream());
               
               while(true)
               {
                   String str = in.readUTF();//блокирующая операция!!!
                   
                   System.out.println("A message from a client: " + str);

                      if(str.equalsIgnoreCase("/end")) 
                      {
                         break;
                      }
                      
                   out.writeUTF("ECHO " + str);
                   out.flush();
               }
              
          }
          catch(IOException ex)
          {
                 System.out.println(ex.getStackTrace());        
          }
    }
}
