package synchro;

class CommonResource{
     
    int x=0;
}
