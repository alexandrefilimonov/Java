/*
 */
package pcfixed;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Anikoton
 */
public class Consumer implements Runnable {
  Q q;

  Consumer(Q q) {
    this.q = q;
    new Thread(this, "Consumer").start();
  }

  @Override
  public void run() {
    while(true) {
        try {
            q.get();
        } catch (InterruptedException ex) {
            Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
  }
}
