package pcfixed;

public class PCFixed {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    Q q = new Q();
    new Producer(q);
    new Consumer(q);
   
    }
}
