package synchroresource;

public class CommonResource {

    int x = 0;

}
