
package callabledemo;

import java.util.concurrent.Callable;

public class TaskWithResults implements Callable<String> {
  private int id;
  public TaskWithResults(int id) {
    this.id = id;
  }
  public String call() {
    return "result of TaskWithResult " + id;
  }
}
