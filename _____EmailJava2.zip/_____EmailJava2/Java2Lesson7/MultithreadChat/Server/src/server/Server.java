package server;

import java.net.*;
import java.util.*;
import java.io.*;

public class Server {

    public static int clientNumber= 0;
    public static void main(String[] args) {

        new MServer();
    
    }//main
}//public class Server
