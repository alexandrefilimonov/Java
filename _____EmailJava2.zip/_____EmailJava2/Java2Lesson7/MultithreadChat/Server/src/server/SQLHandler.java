package server;

import java.sql.*;

public class SQLHandler {

    private static Connection connection;
    private static Statement stmt;
    public static void connect()
    {
        try//нунжо "вытолкнуть" наверх
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/world?useSSL=false","root","DeltaDental!");
            System.out.println("Connected");
            stmt = connection.createStatement();
        }
        catch(Exception ex)
        {
            ex.getStackTrace();
            System.out.println("Not connected");
        }
    }//connect()


    public static String getNickByLogPass(String login, String password)
    {
        // User=Bob username=bob password=12345
        // User=Nickolay username=nick3 password=67890
        try {

            ResultSet rs = stmt.executeQuery("SELECT user_name FROM user WHERE user_login='" + login + "' AND user_password='" + password + "';");

            if(rs.next())//если в наборе есть данные, ...
            {
                return rs.getString("user_name");//вернуть строку из набора
            }

        } catch (SQLException ex) {
            ex.getStackTrace();
        }

        return null;//нет такого клиента
    }


    public static void disconnect()
    {
        try
        {
            connection.close();//осовбодить ресурсы подключения
        }
        catch(Exception ex)
        {
            ex.getStackTrace();
        }
    }//disconnect()
}//public class SQLHandler
