/*package ru.geekbrains.Lesson1;
public class Main {
    public static void main(String[] args) 
	{	
			final int size = 10000000; //10 000 000;
			final int h = size/2;
			
			float[] arr = new float[size];
			
			for (int i=0; i<size; i++) {
				arr[i]= 1;
			}
			Main.m1(arr, size);
			
			for (int i=0; i<size; i++) {
				arr[i]= 1;
			}
			Main.m2(arr, h);
			
    }
	static void m1(float[] arr, int size) {
		long a = System.currentTimeMillis();
		for (int i=0; i<size; i++) {
			arr[i]=(float)(arr[i]*Math.sin(0.2f+i/5)*Math.cos(0.2f+i/5)*Math.cos(0.4f+i/2));
		}
		System.out.println("First:");
		System.out.println(System.currentTimeMillis()-a);
	}
	static void m2(float[] arr, int h) {
		float[] a1 = new float[h];
		float[] a2 = new float[h];
		long a = System.currentTimeMillis();
		System.arraycopy(arr,0,a1,0,h);
		System.arraycopy(arr,h,a2,0,h);
		
		Main e1 = new Main();
		new Thread(()->e1.v1(a1, h)).start();
		new Thread(()->e1.v2(a2, h)).start();
		System.arraycopy(a1,0,arr,0,h);
		System.arraycopy(a2,0,arr,h,h);
		System.out.println("Second:");
		System.out.println(System.currentTimeMillis()-a);
	}
    public void v1(float[] a1, int h) {
		for (int i=0; i<h; i++) {
			a1[i]=(float)(a1[i]*Math.sin(0.2f+i/5)*Math.cos(0.2f+i/5)*Math.cos(0.4f+i/2));
		}
	}
	public void v2(float[] a2, int h) {
		for (int i=0; i<h; i++) {
			a2[i]=(float)(a2[i]*Math.sin(0.2f+i/5)*Math.cos(0.2f+i/5)*Math.cos(0.4f+i/2));
		}
	}
}*/
package ru.geekbrains.Lesson1;

public class Th1 {
	public static void main ( String [] args ) {
		System . out . println ( "Start" );
		new Thread (() -> method ()). start ();
		new Thread (() -> method ()). start ();
	}
	public synchronized static void method () { // синхронизация по классу
		for ( int i = 0 ; i < 10 ; i ++) {
			System . out . println ( i );
			try {
				Thread . sleep ( 100 );
			} catch ( InterruptedException e ) {
				e . printStackTrace ();
			}
		}
	}
}