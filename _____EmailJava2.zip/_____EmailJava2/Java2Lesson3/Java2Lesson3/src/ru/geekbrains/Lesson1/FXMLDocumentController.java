package ru.geekbrains.Lesson1;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class FXMLDocumentController implements Initializable {

    @FXML
    private Label lblChat;

    @FXML
    private Label lblMessage;

    @FXML
    private TextField txtMessage;

    @FXML
    private Button btnSend;

    @FXML
    private void handleButtonAction(ActionEvent event) {
        //System.out.println("You clicked me!");
        //btnSend.setText("Отослать сообщение");
        //String txt_name = ((TextField)event.getSource()).getText();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd HH:mm:ss");
        Date date = new Date();
        if( lblChat.getText()!="") {
            lblChat.setText(lblChat.getText() + '\n' + dateFormat.format(date) + ": " + txtMessage.getText());
        }
        else lblChat.setText(lblChat.getText() + dateFormat.format(date) + ": " + txtMessage.getText());
        txtMessage.setText("");
        //String btn_name = ((Button)event.getSource()).getText();
        //txtMessage.setText(btn_name);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

}