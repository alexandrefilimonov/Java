package ru.geekbrains.Lesson1;

public class Client {
	public static void main(String [] args) {
		new MyWindow();
	}
}
