package ru.geekbrains.Lesson8;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class MyWindow7 extends JFrame {
    public MyWindow7() {
        setBounds( 500 , 500 , 400 , 300 );
        setTitle( "Demo 7" );
        setDefaultCloseOperation( WindowConstants . EXIT_ON_CLOSE );
        JTextField field = new JTextField ();
        add( field );

        field.addActionListener( new ActionListener () {
            @Override
            public void actionPerformed( ActionEvent e ) {
                System.out.println("Your message: " + field . getText ());
            }
        });
        setVisible ( true );
    }
}