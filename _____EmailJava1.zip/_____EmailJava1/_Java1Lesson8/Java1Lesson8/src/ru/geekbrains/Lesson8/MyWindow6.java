package ru.geekbrains.Lesson8;
import javax.swing.*;
import java.awt.*;

public class MyWindow6 extends JFrame {
    public MyWindow6() {
        setBounds ( 500 , 500 , 400 , 300 );
        setTitle ( "GridLayoutDemo 6" );
        setDefaultCloseOperation ( WindowConstants . EXIT_ON_CLOSE );
        JButton [] jbs = new JButton [ 10 ];
        setLayout ( new GridLayout ( 4 , 3 ));
        for ( int i = 0 ; i < jbs . length ; i ++) {
            jbs [ i ] = new JButton ( "#" + i );
            add ( jbs [ i ]);
        }
        setVisible ( true );
    }
}
