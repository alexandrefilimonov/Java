package ru.geekbrains.Lesson8;
import javax.swing.*;
import java.awt.*;

public class MyWindow5 extends JFrame {
    public MyWindow5 () {
        setBounds ( 500 , 500 , 400 , 300 );
        setTitle ( "FlowLayoutDemo 5" );
        setDefaultCloseOperation ( WindowConstants . EXIT_ON_CLOSE );
        JButton [] jbs = new JButton [ 10 ];
        setLayout ( new FlowLayout ());
        for ( int i = 0 ; i < jbs . length ; i ++) {
            jbs [ i ] = new JButton ( "#" + i );
            add ( jbs [ i ]);
        }
        setVisible ( true );
    }
}