package ru.geekbrains.Lesson8;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.WindowConstants;
import java.io.IOException;
import java.io.BufferedReader;
import java.awt.BorderLayout;
import java.lang.String;

class J1Lesson8v1 {
    public static void main(String[] args) {
		//MyWindow1 myWindow1 = new MyWindow1();
		//MyWindow2 myWindow2 = new MyWindow2();
		//MyWindow3 myWindow3 = new MyWindow3();
		//MyWindow4 myWindow4 = new MyWindow4();
		//MyWindow5 myWindow5 = new MyWindow5();
		//MyWindow6 myWindow6 = new MyWindow6();
		//MyWindow7 myWindow7 = new MyWindow7();
		MyWindow8 myWindow8 = new MyWindow8();
    }
}



