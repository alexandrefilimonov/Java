package ru.geekbrains.Lesson8;

import javax.swing.*;

public class MyWindow1 extends JFrame {
    public MyWindow1() {
        setTitle("Test Window 1");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBounds(300, 300, 400, 400);
        setVisible(true);
    }
}
