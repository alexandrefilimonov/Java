package ru.geekbrains.Lesson1;

class Dog extends Animal{
	
    public Dog(String name, double mDistanceToRun, double mDistanceToJump, double mDistanceToSwim){
        this.animalName = name;
        this.maxDistanceToRun = mDistanceToRun;
        this.maxDistanceToJump = mDistanceToJump;
        this.maxDistanceToSwim = mDistanceToSwim;		
    }
}




