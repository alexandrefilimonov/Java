package ru.geekbrains.Lesson1;

// This class manages a simple entry for a PhoneBook. It stores a first
// name, last name and a phone number.
import java.io.*;
//import java.util.Scanner;

public class PhoneBookEntry {
    private String lastName;
    private int number;
    public PhoneBookEntry(String ln, int num) {
        lastName = ln;
        number = num;
    }

    // Changes the phone number for the current object to newnum.
    public void changeNumber(int newnum) {
        number = newnum;
    }

    // Changes the last name for the current object to newlastname.
    public void changeLastName(String newlastname) {
        lastName = newlastname;
    }

    // Returns a string representation of the object.
    public String toString() {
        return lastName+"\t"+(number/10000)+"-"+(number%10000);
    }

    // Returns true iff ln is the same as the last name of the current
    // object.
    public boolean sameLastName(String ln) {
        return (lastName.equals(ln));
    }

    // Prompts the user for information about a PhoneBookEntry object and
    // returns a newly created object based on that information.
    public static PhoneBookEntry add(String ln, int num) {
        return new PhoneBookEntry(ln, num);
    }
}





