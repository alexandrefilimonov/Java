package ru.geekbrains.Lesson7;

public class TestsClass {

    Array1and4.start(Array1and4, "Array1and4");
    //ArrayAfter4.start(ArrayAfter4, "ArrayAfter4");

}
