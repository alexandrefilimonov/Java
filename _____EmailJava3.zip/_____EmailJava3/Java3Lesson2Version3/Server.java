package server;

import java.net.*;
import java.util.*;
import java.io.*;

public class Server {

    public static void main(String[] args) {

       MServer srv = new MServer();
    
    }//main
}//public class Server
