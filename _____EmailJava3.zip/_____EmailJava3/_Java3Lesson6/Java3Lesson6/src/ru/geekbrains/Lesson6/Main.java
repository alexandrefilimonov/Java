package ru.geekbrains.Lesson6;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.lang.String;
import java.util.*;
import org.junit.*;
import org.junit.runners.*;

public class Main {
    public static void main(String[] args) {


        //System.out.println("Array");
        //Array1and4 aa = new Array1and4(3);

    }
}
