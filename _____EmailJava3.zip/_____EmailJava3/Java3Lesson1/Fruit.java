package ru.geekbrains.Lesson1;

public abstract class Fruit{
    protected String fruitName;
    protected double weight;

    public void display(){
        System.out.println("Name: "+this.fruitName);
    }
}




