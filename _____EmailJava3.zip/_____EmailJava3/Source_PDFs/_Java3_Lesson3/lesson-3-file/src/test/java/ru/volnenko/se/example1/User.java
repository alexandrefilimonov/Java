package ru.volnenko.se.example1;

import java.io.Serializable;

/**
 * @author Denis Volnenko
 */
class User implements Serializable {

    String login;

    String email;

}
