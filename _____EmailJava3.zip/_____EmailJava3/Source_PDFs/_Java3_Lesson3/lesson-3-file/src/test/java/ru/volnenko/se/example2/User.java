package ru.volnenko.se.example2;

import java.io.Serializable;

/**
 * @author Denis Volnenko
 */
class User implements Serializable {

    String login;

    String email;

    transient String nick;

}
