package ru.volnenko.se.example3;

import java.io.Serializable;

/**
 * @author Denis Volnenko
 */
class User implements Serializable {

    String login;

    String email;

    User() {
    }

    User(String login, String email) {
        this.login = login;
        this.email = email;
    }

}
