package ru.volnenko.se.example7;

import org.junit.Assert;
import org.junit.Test;

import java.io.InputStream;
import java.util.Properties;

/**
 * @author Denis Volnenko
 */
public class Example7 {

    @Test
    public void test() throws Exception {
        final InputStream inputStream = ClassLoader.getSystemResourceAsStream("test.properties");
        final Properties properties = new Properties();
        properties.load(inputStream);
        Assert.assertEquals(properties.get("a").toString(), "www");
        Assert.assertEquals(properties.get("b").toString(), "zzz");
    }

}
