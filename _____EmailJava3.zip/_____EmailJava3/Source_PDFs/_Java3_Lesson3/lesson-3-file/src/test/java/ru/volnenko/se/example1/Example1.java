package ru.volnenko.se.example1;

import org.junit.Assert;
import org.junit.Test;

import java.io.*;

/**
 * @author Denis Volnenko
 */
public class Example1 {

    @Test(expected = NotSerializableException.class)
    public void testFail() throws Exception {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        final ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
        objectOutputStream.writeObject(new Role("admin"));
        objectOutputStream.close();
        byteArrayOutputStream.close();
    }

    @Test
    public void test() throws Exception {
        final User user = new User();
        user.email = "1@1.ru";
        user.login = "1234";

        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        final ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
        objectOutputStream.writeObject(user);
        objectOutputStream.close();
        byteArrayOutputStream.close();

        final byte[] data = byteArrayOutputStream.toByteArray();
        System.out.println(new String(data));

        final ByteArrayInputStream byteInputStream = new ByteArrayInputStream(data);
        final ObjectInputStream objectInputStream = new ObjectInputStream(byteInputStream);

        final User userLoaded = (User) objectInputStream.readObject();
        objectInputStream.close();
        byteInputStream.close();

        Assert.assertEquals(user.email, userLoaded.email);
        Assert.assertEquals(user.login, userLoaded.login);
        Assert.assertNotEquals(user, userLoaded);
    }

}
