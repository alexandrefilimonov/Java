package ru.volnenko.se.example9;

import org.junit.Test;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;

/**
 * @author Denis Volnenko
 */
public class Example9 {

    @Test
    public void test() throws Exception {
        final String link = "http://localhost/1.txt";

        final URL url = new URL(link);
        final URLConnection urlConnection = url.openConnection();

        final InputStream inputStream = urlConnection.getInputStream();
        final InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        final BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        final StringBuilder response = new StringBuilder();

        String inputLine;
        final String newLine = System.getProperty("line.separator");
        while ((inputLine = bufferedReader.readLine()) != null)
        {
            response.append(inputLine + newLine);
        }

        bufferedReader.close();
        System.out.println(response.toString());
    }

}
