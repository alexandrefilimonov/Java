package ru.volnenko.se.example1;

/**
 * @author Denis Volnenko
 */
public class Role {

    String name;

    public Role(String name) {
        this.name = name;
    }

}
