package ru.volnenko.se.example8;

import org.junit.Assert;
import org.junit.Test;

import java.io.InputStream;
import java.util.Properties;

/**
 * @author Denis Volnenko
 */
public class Example8 {

    @Test
    public void test() throws Exception {
        final InputStream inputStream = Example8.class.getResourceAsStream("mega.properties");
        final Properties properties = new Properties();
        properties.load(inputStream);
        Assert.assertEquals(properties.get("a").toString(), "www");
        Assert.assertEquals(properties.get("b").toString(), "zzz");
    }

}
