package ru.volnenko.se.example2;

import org.junit.Assert;
import org.junit.Test;

import java.io.*;

/**
 * @author Denis Volnenko
 */
public class Example2 {

    @Test
    public void test() throws Exception {
        final User user = new User();
        user.email = "1@1.ru";
        user.login = "1234";
        user.nick = "admin";

        final File tempFile = File.createTempFile("user-file", ".tmp");
        final FileOutputStream fileOutputStream = new FileOutputStream(tempFile);
        final ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(user);
        objectOutputStream.close();
        fileOutputStream.close();

        System.out.println(tempFile.getAbsoluteFile());

        final FileInputStream fileInputStream = new FileInputStream(tempFile);
        final ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
        final User userLoaded = (User) objectInputStream.readObject();
        objectInputStream.close();
        fileInputStream.close();

        Assert.assertEquals(user.email, userLoaded.email);
        Assert.assertEquals(user.login, userLoaded.login);
        Assert.assertNotNull(user.nick);
        Assert.assertNull(userLoaded.nick);
        Assert.assertNotEquals(user, userLoaded);
        tempFile.deleteOnExit();
    }

}
