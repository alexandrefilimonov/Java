package ru.volnenko.se.example10;

import org.junit.Test;

import java.io.File;

/**
 * @author Denis Volnenko
 */
public class Example10 {

    @Test
    public void test() {
        final File file = new File("/data/test/1/2/3");
        file.mkdirs();
    }

}
