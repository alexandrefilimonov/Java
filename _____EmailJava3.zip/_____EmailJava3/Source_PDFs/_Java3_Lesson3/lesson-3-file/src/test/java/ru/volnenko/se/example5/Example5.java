package ru.volnenko.se.example5;

import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * @author Denis Volnenko
 */
public class Example5 {

    @Test
    public void testFile() throws Exception {
        final File file = File.createTempFile("test", ".tmp");
        System.out.println(file.getAbsoluteFile());
        Assert.assertFalse(file.isDirectory());
        Assert.assertTrue(file.canRead());
        Assert.assertTrue(file.canWrite());
        Assert.assertTrue(file.isFile());
        file.deleteOnExit();
    }

    @Test
    public void testFolder() throws Exception {
        final Path path = Files.createTempDirectory("test");
        final File file = path.toFile();
        System.out.println(file.getAbsoluteFile());
        Assert.assertTrue(file.isDirectory());
        Assert.assertTrue(file.canRead());
        Assert.assertTrue(file.canWrite());
        Assert.assertFalse(file.isFile());
        file.deleteOnExit();
    }

}
