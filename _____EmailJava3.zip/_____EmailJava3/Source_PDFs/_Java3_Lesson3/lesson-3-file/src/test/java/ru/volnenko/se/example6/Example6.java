package ru.volnenko.se.example6;

import org.junit.Test;

import java.io.File;
import java.nio.file.Files;

/**
 * @author Denis Volnenko
 */
public class Example6 {

    @Test
    public void test() throws Exception {
        final File file = File.createTempFile("test", ".tmp");
        final String text = "HELLO WORLD";

        System.out.println(file.getAbsoluteFile());

        final byte[] bytes = text.getBytes("UTF-8");
        Files.write(file.toPath(), bytes);

        final byte[] data = Files.readAllBytes(file.toPath());
        System.out.println(new String(data));

        file.deleteOnExit();
    }

}
