package ru.volnenko.se.example3;

import org.junit.Assert;
import org.junit.Test;

import java.io.*;

/**
 * @author Denis Volnenko
 */
public class Example3 {

    @Test
    public void test() throws Exception {
        final File tempFile = File.createTempFile("user-file", ".tmp");
        final FileOutputStream fileOutputStream = new FileOutputStream(tempFile);
        final ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(new User("1@1.ru", "111"));
        objectOutputStream.writeObject(new User("2@2.ru", "222"));
        objectOutputStream.close();
        fileOutputStream.close();

        System.out.println(tempFile.getAbsoluteFile());

        final FileInputStream fileInputStream = new FileInputStream(tempFile);
        final ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
        final User userFirst = (User) objectInputStream.readObject();
        final User userSecond = (User) objectInputStream.readObject();
        objectInputStream.close();
        fileInputStream.close();

        Assert.assertNotNull(userFirst.login);
        Assert.assertNotNull(userFirst.email);
        Assert.assertNotNull(userSecond.login);
        Assert.assertNotNull(userSecond.email);

        tempFile.deleteOnExit();
    }

}
