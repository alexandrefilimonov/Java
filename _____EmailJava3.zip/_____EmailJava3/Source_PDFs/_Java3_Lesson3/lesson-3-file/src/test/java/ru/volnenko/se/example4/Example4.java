package ru.volnenko.se.example4;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author Denis Volnenko
 */
public class Example4 {

    @Test
    public void testR() throws Exception {
        final InputStream inputStream = ClassLoader.class.getResourceAsStream("/test.txt");
        final StringBuilder textBuilder = new StringBuilder();
        final Charset charset = Charset.forName(StandardCharsets.UTF_8.name());
        final InputStreamReader inputStreamReader = new InputStreamReader(inputStream, charset);
        try (final Reader reader = new BufferedReader(inputStreamReader)) {
            int c = 0;
            while ((c = reader.read()) != -1) {
                textBuilder.append((char) c);
            }
        }
        System.out.println(textBuilder.toString());
    }

    @Test
    public void test() throws Exception {
        final URL url = getClass().getResource("/test.txt");
        final URI uri = url.toURI();
        final Path path = Paths.get(uri);
        final byte[] bytes = Files.readAllBytes(path);
        System.out.println(bytes);
        System.out.println(new String(bytes));
    }

    @Test
    public void testSimple() throws Exception {
        System.out.println(new String(Files.readAllBytes(Paths.get(getClass().getResource("/test.txt").toURI()))));
    }

}
