package ru.geekbrains.Lesson5;
import java.util.*;
import org.junit.*;
import org.junit.runners.*;

public class CalcMassAddTest {
    @Parameterized.Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList( new Object[][]{
                { 0 , 0 , 0 },
                { 1 , 1 , 2 },
                { 2 , 2 , 4 },
                { 5 , 5 , 10 },
                { 4 , 2 , 6 },
                { 1 , 4 , 4 },
                { 6 , - 2 , 4 },
                {- 1 , 5 , 4 },
        });
    }
    private int a;
    private int b;
    private int c;
    //public CalcMassAddTest() {
    //}
    public void CalcMassAddTest ( int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    Calculator calculator;
    @Before
    public void init () {
        calculator = new Calculator();
    }
    @Test
    public void massTestAdd () {
        Assert.assertEquals(c, calculator.add(a, b));
    }
}
