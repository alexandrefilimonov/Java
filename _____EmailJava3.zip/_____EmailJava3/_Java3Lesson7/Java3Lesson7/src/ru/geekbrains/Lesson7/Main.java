package ru.geekbrains.Lesson7;

import java.lang.String;

public class Main {
    public static void main(String[] args) {


        //System.out.println("Array");
        //Array1and4 aa = new Array1and4(3);

    }
}
